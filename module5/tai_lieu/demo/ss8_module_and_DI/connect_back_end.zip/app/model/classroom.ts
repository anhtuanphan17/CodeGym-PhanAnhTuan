export class Classroom {
  id: number;
  nameClass: string;

  constructor(id: number, nameClass: string) {
    this.id = id;
    this.nameClass = nameClass;
  }
}
